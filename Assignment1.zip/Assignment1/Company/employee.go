package Company

type Employee interface {
	GetDetails()
}
