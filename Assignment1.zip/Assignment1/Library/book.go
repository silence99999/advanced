package Library

type Book struct {
	ID         int
	Title      string
	Author     string
	IsBorrowed bool
}
