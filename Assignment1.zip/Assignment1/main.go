package main

import (
	"github.com/AmirAlimov/Assignment1/Bank"
	"github.com/AmirAlimov/Assignment1/Company"
	"github.com/AmirAlimov/Assignment1/Library"
	"github.com/AmirAlimov/Assignment1/Shapes"
)

func main() {
	Library.CLILibrary()
	Shapes.Example()
	Company.Example()
	Bank.CLIBank()
}
